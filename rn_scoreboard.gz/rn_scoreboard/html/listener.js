var visable = false;

$(function () {
	window.addEventListener('message', function (event) {

		if (event.data.action == "updatePraca"){
			$('#praca').html(event.data.praca);
		}

		switch (event.data.action) {
			case 'toggle':
				if (visable) {
					$('#wrap').hide();
				} else {
					$('#wrap').show();
				}

				visable = !visable;
				break;

			case 'close':
				$('#wrap').hide();
				visable = false;
				break;

			case 'toggleID':

				if (event.data.state) {
					$('td:nth-child(2),th:nth-child(2)').show();
					$('td:nth-child(5),th:nth-child(5)').show();
				} else {
					$('td:nth-child(2),th:nth-child(2)').hide();
					$('td:nth-child(5),th:nth-child(5)').hide();
				}

				break;

			case 'updatePlayerJobs':
				var jobs = event.data.jobs;

				$('#player_count').html(jobs.player_count);

				$('#ems').html(jobs.ems);
				$('#police').html(jobs.police);
				if(jobs.taxi == 0){
					$('#taxi').html('NPC');
				}else{
					$('#taxi').html(jobs.taxi);
				}
				$('#mechanic').html(jobs.mechanic);
				$('#cardealer').html(jobs.cardealer);
				$('#safj').html(jobs.safj);
				break;

			case 'updatePlayerList':
				$('#playerlist tr:gt(0)').remove();
				$('#playerlist').append(event.data.players);
				break;

			case 'updatePing':
				updatePing(event.data.players);
				break;

			case 'updateServerInfo':
				if (event.data.maxPlayers) {
					$('#max_players').html(event.data.maxPlayers);
				}

				if (event.data.uptime) {
					$('#server_uptime').html(event.data.uptime);
				}

				break;

			default:
				break;
		}
	}, false);
});

// Todo: not the best code
function updatePing(players) {
	jQuery.each(players, function (index, element) {
		if (element != null) {
			$('#playerlist tr:not(.heading)').each(function () {
				$(this).find('td:nth-child(2):contains(' + element.id + ')').each(function () {
					$(this).parent().find('td').eq(2).html(element.ping);
				});

				$(this).find('td:nth-child(5):contains(' + element.id + ')').each(function () {
					$(this).parent().find('td').eq(5).html(element.ping);
				});
			});
		}
	});
}